export function button(){
    return `<input></input><br>\n`;
}