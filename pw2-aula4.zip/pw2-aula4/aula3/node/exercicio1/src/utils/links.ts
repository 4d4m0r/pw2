export function createLink(filename: string) {
    return `<a href="/${filename}">${filename}</a><br>\n`;
}

export function voltar() {
    return `<a href="/">Voltar</a><br>\n`;
}