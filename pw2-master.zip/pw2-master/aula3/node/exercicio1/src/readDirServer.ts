import { createServer, IncomingMessage, ServerResponse } from "http";
import { readdir } from "fs/promises"
import { config as dotenvConfig } from "dotenv";

dotenvConfig();

const PORT = process.env.PORT ?? 3333;
const DIR = process.argv[2] ?? process.env.DEFAULT_DIR

const server = createServer(async (req: IncomingMessage, res: ServerResponse) => {
    const file = await readdir(DIR)
    res.writeHead(200, { "Content-Type": "text/html;charset=utf-8" })
    res.write(file.join("<br>"))
    res.end()
});

server.listen(PORT, () => {
    console.log(`Aplicação rodando na porta ${PORT}`)
});
