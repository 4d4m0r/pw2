if [ "$NODE_ENV" = "production" ]; then
    echo "Frontend inicializada em produção"
    npm run build
    npm start
else 
    echo "Frontend inicializada em desenvolvimento"
    npm run dev
fi